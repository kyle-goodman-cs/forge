# Week 8: Interview practice, without a timer first

This kit starts the checkpoint core. The complete local lab below goes beyond browser checks. Fill in core.py, add your own cases, then build the workflow.

## Setup

Windows PowerShell:
```text
py -m venv .venv
.venv\Scripts\python -m unittest -v
```
macOS/Linux:
```text
python3 -m venv .venv
.venv/bin/python -m unittest -v
```
The included tests start red because the implementation is yours to write. They use only the standard library. Install optional packages such as pytest, Requests, or FastAPI in this environment when the lab calls for them.

## Core challenge
Write is_anagram(a, b). Ignore spaces and letter case, but preserve all other characters. Return whether character counts match.

## Build the full lab
1. Solve search, duplicate detection, and counting using your own examples.
2. For each, write a brute-force approach before an improved one.
3. Record normal, empty, repeated, and boundary cases.
4. Explain one solution aloud without reading its code.
5. Rebuild a selected problem after a few days.
6. Only add a time limit once you can reason through the pattern accurately.

## Acceptance criteria
- [ ] You can describe why your data structure fits.
- [ ] Time and extra space are stated with a defined n.
- [ ] You can adapt the input or tie rule without copying a solution.
- [ ] You distinguish practice recall from solving an unfamiliar problem.

## Deliverables
- core.py with your implementation
- test_core.py with normal, empty, boundary, and invalid cases where applicable
- README.md with run commands, sample input/output, decisions, and limitations
- Evidence note: what you ran, what failed, what you changed, and help used

## References
- Python: data structures: https://docs.python.org/3/tutorial/datastructures.html
- Python: collections: https://docs.python.org/3/library/collections.html
- Python: control flow and functions: https://docs.python.org/3/tutorial/controlflow.html
