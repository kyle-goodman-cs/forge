def is_anagram(a, b):
    # Write your solution here
    pass
