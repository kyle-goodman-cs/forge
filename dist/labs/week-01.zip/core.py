def reward(score, won):
    # Write your solution here
    pass
