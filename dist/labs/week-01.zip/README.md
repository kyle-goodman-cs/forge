# Week 1: Build a small reward calculator

This kit starts the checkpoint core. The complete local lab below goes beyond browser checks. Fill in core.py, add your own cases, then build the workflow.

## Setup

Windows PowerShell:
```text
py -m venv .venv
.venv\Scripts\python -m unittest -v
```
macOS/Linux:
```text
python3 -m venv .venv
.venv/bin/python -m unittest -v
```
The included tests start red because the implementation is yours to write. They use only the standard library. Install optional packages such as pytest, Requests, or FastAPI in this environment when the lab calls for them.

## Core challenge
Write reward(score, won). Start with score * 2 XP. Add 50 if won is True. Return the total.

## Build the full lab
1. Before coding, write two input/output examples for a game reward rule.
2. Create core.py with one function that calculates XP from a score and win flag.
3. In main.py, call it with three examples and print the returned values.
4. Add a second function that labels the XP using clear cutoff rules.
5. Write one ordinary case, one exact-cutoff case, and one zero case in test_core.py.
6. Run the files locally using the Start Here guide. Explain each line aloud.

## Acceptance criteria
- [ ] An ordinary input produces your documented result.
- [ ] Zero and exact-cutoff cases work.
- [ ] Core functions return values; presentation prints them.
- [ ] You can rewrite the smallest function without copying it.

## Deliverables
- core.py with your implementation
- test_core.py with normal, empty, boundary, and invalid cases where applicable
- README.md with run commands, sample input/output, decisions, and limitations
- Evidence note: what you ran, what failed, what you changed, and help used

## References
- W3Schools: variables: https://www.w3schools.com/python/python_variables.asp
- W3Schools: functions: https://www.w3schools.com/python/python_functions.asp
- Python: numbers, strings, and lists: https://docs.python.org/3/tutorial/introduction.html
- Python: control flow and functions: https://docs.python.org/3/tutorial/controlflow.html
