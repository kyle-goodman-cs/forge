# Week 9: Trace and test the patterns

This kit starts the checkpoint core. The complete local lab below goes beyond browser checks. Fill in core.py, add your own cases, then build the workflow.

## Setup

Windows PowerShell:
```text
py -m venv .venv
.venv\Scripts\python -m unittest -v
```
macOS/Linux:
```text
python3 -m venv .venv
.venv/bin/python -m unittest -v
```
The included tests start red because the implementation is yours to write. They use only the standard library. Install optional packages such as pytest, Requests, or FastAPI in this environment when the lab calls for them.

## Core challenge
Write binary_search(nums, target). nums is sorted ascending with unique values. Return the matching index or -1. Use binary search.

## Build the full lab
1. Draw a palindrome scan and binary search on paper before coding.
2. Add a bracket checker and test nesting, reversed symbols, and an empty string.
3. Add a window-sum function and include all-negative values.
4. Describe the invariant for each function in one sentence.
5. Write tests for size-one and missing-target searches.
6. After the guided attempts, change one contract and solve the variation independently.

## Acceptance criteria
- [ ] Every loop demonstrably makes progress.
- [ ] Boundary and empty cases are covered.
- [ ] You can explain the sorted-input requirement.
- [ ] An unfamiliar variation is attempted without the reference open.

## Deliverables
- core.py with your implementation
- test_core.py with normal, empty, boundary, and invalid cases where applicable
- README.md with run commands, sample input/output, decisions, and limitations
- Evidence note: what you ran, what failed, what you changed, and help used

## References
- Python: control flow and functions: https://docs.python.org/3/tutorial/controlflow.html
- Python: data structures: https://docs.python.org/3/tutorial/datastructures.html
- Python: collections: https://docs.python.org/3/library/collections.html
