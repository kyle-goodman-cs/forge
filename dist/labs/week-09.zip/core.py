def binary_search(nums, target):
    # Write your solution here
    pass
