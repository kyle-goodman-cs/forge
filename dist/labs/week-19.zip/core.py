def priority_order(tasks):
    # Plan, implement, then run the checks.
    pass
