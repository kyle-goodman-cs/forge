# Week 19: Find a path through your dungeon

This kit starts the checkpoint core. The complete local lab below goes beyond browser checks. Fill in core.py, add your own cases, then build the workflow.

## Setup

Windows PowerShell:
```text
py -m venv .venv
.venv\Scripts\python -m unittest -v
```
macOS/Linux:
```text
python3 -m venv .venv
.venv/bin/python -m unittest -v
```
The included tests start red because the implementation is yours to write. They use only the standard library. Install optional packages such as pytest, Requests, or FastAPI in this environment when the lab calls for them.

## Core challenge
Write priority_order(tasks). tasks contains [name, priority] pairs. Use a heap to return names in priority ascending order, preserving original order for equal priorities.

## Build the full lab
1. Represent walkable map cells as an unweighted graph.
2. Implement BFS returning both distance and a reconstructed route.
3. Test a cycle, an unreachable treasure, and start equal to goal.
4. Implement one nested-data traversal recursively and with an explicit stack.
5. Build and reverse a small linked chain with a Node class.
6. Explain operation costs and choose one unfamiliar variation to solve.

## Acceptance criteria
- [ ] The route contains valid adjacent moves.
- [ ] The shortest unweighted distance matches a hand-worked example.
- [ ] Cycles terminate without repeated exploration.
- [ ] You can draw linked references and explain the heap tie policy.

## Deliverables
- core.py with your implementation
- test_core.py with normal, empty, boundary, and invalid cases where applicable
- README.md with run commands, sample input/output, decisions, and limitations
- Evidence note: what you ran, what failed, what you changed, and help used

## References
- Python: collections: https://docs.python.org/3/library/collections.html
- Python: heapq: https://docs.python.org/3/library/heapq.html
- Python: control flow and functions: https://docs.python.org/3/tutorial/controlflow.html
- Python: data structures: https://docs.python.org/3/tutorial/datastructures.html
