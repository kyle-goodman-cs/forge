def playtime_report(records):
    # Write your solution here
    pass
