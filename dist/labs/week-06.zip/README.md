# Week 6: Ship the playtime report

This kit starts the checkpoint core. The complete local lab below goes beyond browser checks. Fill in core.py, add your own cases, then build the workflow.

## Setup

Windows PowerShell:
```text
py -m venv .venv
.venv\Scripts\python -m unittest -v
```
macOS/Linux:
```text
python3 -m venv .venv
.venv/bin/python -m unittest -v
```
The included tests start red because the implementation is yours to write. They use only the standard library. Install optional packages such as pytest, Requests, or FastAPI in this environment when the lab calls for them.

## Core challenge
Write playtime_report(records). Each record has game and minutes. Sum minutes per game. Return a dictionary of totals.

## Build the full lab
1. Create a JSON fixture with at least five sessions and repeated games.
2. Read the fixture with a context manager.
3. Aggregate minutes by game in a pure function.
4. Write a sorted CSV report using DictWriter or writer.
5. Test an empty dataset, a comma in a game name, and invalid input shape.
6. Preserve the input and document an example output file.

## Acceptance criteria
- [ ] Totals match manually calculated results.
- [ ] Quoted fields round-trip through csv.
- [ ] The core accepts in-memory records for tests.
- [ ] Running on a new fixture produces a new report without editing source code.

## Deliverables
- core.py with your implementation
- test_core.py with normal, empty, boundary, and invalid cases where applicable
- README.md with run commands, sample input/output, decisions, and limitations
- Evidence note: what you ran, what failed, what you changed, and help used

## References
- Python: input and output: https://docs.python.org/3/tutorial/inputoutput.html
- Python: csv: https://docs.python.org/3/library/csv.html
- Python: pathlib: https://docs.python.org/3/library/pathlib.html
