def dungeon(commands):
    # Write your solution here
    pass
