# Week 4: Ship the tiny dungeon

This kit starts the checkpoint core. The complete local lab below goes beyond browser checks. Fill in core.py, add your own cases, then build the workflow.

## Setup

Windows PowerShell:
```text
py -m venv .venv
.venv\Scripts\python -m unittest -v
```
macOS/Linux:
```text
python3 -m venv .venv
.venv/bin/python -m unittest -v
```
The included tests start red because the implementation is yours to write. They use only the standard library. Install optional packages such as pytest, Requests, or FastAPI in this environment when the lab calls for them.

## Core challenge
Write dungeon(commands). Start at [0, 0]. Apply N/S/E/W movement as before. Ignore unknown commands. Return the final [x, y].

## Build the full lab
1. Define a 5×5 map with start, treasure, and two wall cells.
2. Implement a pure step(state, command) function.
3. Keep invalid moves in place and report when treasure is reached.
4. Add a terminal loop using input() only in main.py, outside the browser.
5. Write tests for walls, edges, unknown commands, and a winning route.
6. Document launch and replay instructions; finish the terminal version before adding graphics.

## Acceptance criteria
- [ ] A documented route reaches the treasure.
- [ ] Walls and boundaries behave consistently.
- [ ] Core tests require no user input.
- [ ] A new player can run the game from the README.

## Deliverables
- core.py with your implementation
- test_core.py with normal, empty, boundary, and invalid cases where applicable
- README.md with run commands, sample input/output, decisions, and limitations
- Evidence note: what you ran, what failed, what you changed, and help used

## References
- Python: control flow and functions: https://docs.python.org/3/tutorial/controlflow.html
- Python: modules: https://docs.python.org/3/tutorial/modules.html
- Python: unittest: https://docs.python.org/3/library/unittest.html
