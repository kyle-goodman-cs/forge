def patch_game(original, changes):
    # Plan, implement, then run the checks.
    pass
