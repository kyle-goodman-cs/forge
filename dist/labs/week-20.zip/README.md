# Week 20: Build a local game-library API

This kit starts the checkpoint core. The complete local lab below goes beyond browser checks. Fill in core.py, add your own cases, then build the workflow.

## Setup

Windows PowerShell:
```text
py -m venv .venv
.venv\Scripts\python -m unittest -v
```
macOS/Linux:
```text
python3 -m venv .venv
.venv/bin/python -m unittest -v
```
The included tests start red because the implementation is yours to write. They use only the standard library. Install optional packages such as pytest, Requests, or FastAPI in this environment when the lab calls for them.

## Core challenge
Write patch_game(original, changes). Only title and completed are editable. Return a copy with those keys updated when present; ignore all other change keys. Do not mutate original. Values are already validated for this exercise.

## Build the full lab
1. Install FastAPI locally and create GET /games and POST /games.
2. Reuse tested core functions and a SQLite repository.
3. Add typed request/response models and explicit public fields.
4. Implement a bounded list page and an update route.
5. Test invalid, missing, unauthorized, and successful requests using a fake identity boundary.
6. Run the service locally and document example requests and responses.
7. Document that authentication is a practice boundary unless integrated with a real provider.

## Acceptance criteria
- [ ] Routes return the documented schema and status.
- [ ] Invalid or unauthorized updates do not change storage.
- [ ] Endpoint tests use temporary data.
- [ ] The README includes install, run, test, and sample request commands.

## Deliverables
- core.py with your implementation
- test_core.py with normal, empty, boundary, and invalid cases where applicable
- README.md with run commands, sample input/output, decisions, and limitations
- Evidence note: what you ran, what failed, what you changed, and help used

## References
- FastAPI: first steps: https://fastapi.tiangolo.com/tutorial/first-steps/
- MDN: HTTP overview: https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Overview
- Python: sqlite3: https://docs.python.org/3/library/sqlite3.html
- pytest: getting started: https://docs.pytest.org/en/stable/getting-started.html
