def batch_summary(rows):
    # Plan, implement, then run the checks.
    pass
