# Week 21: Dependable batch importer

This kit starts the checkpoint core. The complete local lab below goes beyond browser checks. Fill in core.py, add your own cases, then build the workflow.

## Setup

Windows PowerShell:
```text
py -m venv .venv
.venv\Scripts\python -m unittest -v
```
macOS/Linux:
```text
python3 -m venv .venv
.venv/bin/python -m unittest -v
```
The included tests start red because the implementation is yours to write. They use only the standard library. Install optional packages such as pytest, Requests, or FastAPI in this environment when the lab calls for them.

## Core challenge
Write batch_summary(rows). A valid row has integer id (exclude booleans) and nonempty stripped string title. Count all invalid rows as rejected. Keep only the first valid occurrence of each id. Return {"accepted": unique valid count, "rejected": invalid count, "duplicates": extra valid occurrences}.

## Build the full lab
1. Create a synthetic file with valid, invalid, and duplicate records.
2. Add --dry-run and produce a proposed import summary.
3. Validate schema and filenames before any write.
4. Persist through a transaction and a unique-id/upsert policy.
5. Write structured log events and a rejection report.
6. Import the same file twice and compare counts and results.
7. Force a failure halfway through and verify the documented recovery behavior.

## Acceptance criteria
- [ ] Every row is accounted for.
- [ ] Reruns do not create unintended duplicates.
- [ ] Dry runs perform no writes.
- [ ] A failure does not report a false complete success.

## Deliverables
- core.py with your implementation
- test_core.py with normal, empty, boundary, and invalid cases where applicable
- README.md with run commands, sample input/output, decisions, and limitations
- Evidence note: what you ran, what failed, what you changed, and help used

## References
- Python: logging: https://docs.python.org/3/library/logging.html
- Python: pathlib: https://docs.python.org/3/library/pathlib.html
- Python: sqlite3: https://docs.python.org/3/library/sqlite3.html
- Python: argparse: https://docs.python.org/3/library/argparse.html
