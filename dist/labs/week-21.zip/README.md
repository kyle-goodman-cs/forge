# Week 21: Dependable batch importer

## Start here

This ZIP is an unfinished checkpoint plus tests. The complete program in the build steps below is yours to create. Passing the supplied tests is only part of the lab.

1. Extract the ZIP into its own folder, for example Documents/Forge Work/week-21.
2. In VS Code, use File > Open Folder to open the folder containing core.py.
3. Choose Terminal > New Terminal. Type the commands below there, not in a .py file.
4. Need help installing Python or using the editor? Return to the Forge browser tab, open chapter 21 in the Quest book, open its independent lab brief, and select First lab? Start guided setup. This works in the local app and the public demo.

## Create the environment (once per lab folder)

Windows PowerShell:
```text
py -m venv .venv
.\.venv\Scripts\python.exe --version
```
macOS/Linux:
```text
python3 -m venv .venv
./.venv/bin/python --version
```
A Python 3 version number confirms the environment works. If Windows has python rather than py, use python -m venv .venv. Select this folder's .venv with VS Code's Python: Select Interpreter command. You do not need to activate it.

## Know the files

- core.py: implement the requested checkpoint function here.
- main.py: build the complete program here, calling functions from core.py as needed. The untouched file only prints a reminder.
- test_core.py: supplied checkpoint tests; add your own tests too.
- cases.json: inputs and expected results used by the supplied tests. Keep these intact.
- README.md: this brief; add your plan, run commands, and sample output here.

## Run tests after saving your files

Windows PowerShell:
```text
.\.venv\Scripts\python.exe -m unittest -v
```
macOS/Linux:
```text
./.venv/bin/python -m unittest -v
```
Expect assertion failures before you implement core.py. They compare the unfinished result with the expected result. An import ERROR or Ran 0 tests needs investigation: make sure the terminal is in the folder containing core.py, test_core.py, and cases.json. OK means the tests that ran passed; you must still check the full lab below. The kit uses built-in unittest, so no extra packages are needed for its tests.

## Run your program

Windows PowerShell:
```text
.\.venv\Scripts\python.exe main.py
```
macOS/Linux:
```text
./.venv/bin/python main.py
```
The untouched main.py is only a starting place. Replace its reminder with your own program. Install extra libraries in .venv only when a later lab needs them.

## Checkpoint contract

Write batch_summary(rows). A valid row has integer id (exclude booleans) and nonempty stripped string title. Count all invalid rows as rejected. Keep only the first valid occurrence of each id. Return {"accepted": unique valid count, "rejected": invalid count, "duplicates": extra valid occurrences}.

## Build the full lab

1. Create a synthetic file with valid, invalid, and duplicate records.
2. Add --dry-run and produce a proposed import summary.
3. Validate schema and filenames before any write.
4. Persist through a transaction and a unique-id/upsert policy.
5. Write structured log events and a rejection report.
6. Import the same file twice and compare counts and results.
7. Force a failure halfway through and verify the documented recovery behavior.

## Acceptance criteria

- [ ] Every row is accounted for.
- [ ] Reruns do not create unintended duplicates.
- [ ] Dry runs perform no writes.
- [ ] A failure does not report a false complete success.

## Deliverables

- core.py with your implementation
- main.py demonstrating the complete program
- test_core.py with normal, empty, boundary, and invalid cases where applicable
- README.md with run commands, sample input/output, decisions, and limitations
- Evidence note: what you ran, what failed, what you changed, and help used

## Evidence to record

Write your example input and expected output before coding. Then record the commands you ran, actual output, a bug you fixed, help used, and anything unfinished. Add at least one test of your own. Check the criteria in Forge after verifying them, and keep a backup of this folder separately from your Forge progress export.

## References

- Python: logging: https://docs.python.org/3/library/logging.html
- Python: pathlib: https://docs.python.org/3/library/pathlib.html
- Python: sqlite3: https://docs.python.org/3/library/sqlite3.html
- Python: argparse: https://docs.python.org/3/library/argparse.html
