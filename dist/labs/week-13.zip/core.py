def exit_result(changes, conflicts, dry_run):
    # Plan, implement, then run the checks.
    pass
