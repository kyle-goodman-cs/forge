# Week 13: Put a real CLI under version control

## Start here

This ZIP is an unfinished checkpoint plus tests. The complete program in the build steps below is yours to create. Passing the supplied tests is only part of the lab.

1. Extract the ZIP into its own folder, for example Documents/Forge Work/week-13.
2. In VS Code, use File > Open Folder to open the folder containing core.py.
3. Choose Terminal > New Terminal. Type the commands below there, not in a .py file.
4. Need help installing Python or using the editor? Return to the Forge browser tab, open chapter 13 in the Quest book, open its independent lab brief, and select First lab? Start guided setup. This works in the local app and the public demo.

## Create the environment (once per lab folder)

Windows PowerShell:
```text
py -m venv .venv
.\.venv\Scripts\python.exe --version
```
macOS/Linux:
```text
python3 -m venv .venv
./.venv/bin/python --version
```
A Python 3 version number confirms the environment works. If Windows has python rather than py, use python -m venv .venv. Select this folder's .venv with VS Code's Python: Select Interpreter command. You do not need to activate it.

## Know the files

- core.py: implement the requested checkpoint function here.
- main.py: build the complete program here, calling functions from core.py as needed. The untouched file only prints a reminder.
- test_core.py: supplied checkpoint tests; add your own tests too.
- cases.json: inputs and expected results used by the supplied tests. Keep these intact.
- README.md: this brief; add your plan, run commands, and sample output here.

## Run tests after saving your files

Windows PowerShell:
```text
.\.venv\Scripts\python.exe -m unittest -v
```
macOS/Linux:
```text
./.venv/bin/python -m unittest -v
```
Expect assertion failures before you implement core.py. They compare the unfinished result with the expected result. An import ERROR or Ran 0 tests needs investigation: make sure the terminal is in the folder containing core.py, test_core.py, and cases.json. OK means the tests that ran passed; you must still check the full lab below. The kit uses built-in unittest, so no extra packages are needed for its tests.

## Run your program

Windows PowerShell:
```text
.\.venv\Scripts\python.exe main.py
```
macOS/Linux:
```text
./.venv/bin/python main.py
```
The untouched main.py is only a starting place. Replace its reminder with your own program. Install extra libraries in .venv only when a later lab needs them.

## Checkpoint contract

Write exit_result(changes, conflicts, dry_run). Return {"exit_code": 2, "message": "resolve conflicts"} when conflicts > 0. Otherwise return code 0 and "preview N changes" when dry_run is True, or "apply N changes" otherwise.

## Build the full lab

1. Create a fresh .venv and select its interpreter in VS Code.
2. Run python --version and record the supported runtime in README.
3. Create a CLI with --help, --limit, and --dry-run.
4. Initialize Git; create a .gitignore for .venv/, __pycache__/, local data, and secrets.
5. Stage one file, edit it again, and inspect both diff views.
6. Create a feature branch, commit a tested change, and open a practice PR.
7. Record the commit hash and the commands another person needs to run the sample.

## Acceptance criteria

- [ ] A clean environment runs the sample.
- [ ] --help works and invalid numeric input is reported.
- [ ] The staged diff matches the intended change.
- [ ] Your repository has a readable README and no committed secrets.

## Deliverables

- core.py with your implementation
- main.py demonstrating the complete program
- test_core.py with normal, empty, boundary, and invalid cases where applicable
- README.md with run commands, sample input/output, decisions, and limitations
- Evidence note: what you ran, what failed, what you changed, and help used

## Evidence to record

Write your example input and expected output before coding. Then record the commands you ran, actual output, a bug you fixed, help used, and anything unfinished. Add at least one test of your own. Check the criteria in Forge after verifying them, and keep a backup of this folder separately from your Forge progress export.

## References

- Python: virtual environments: https://docs.python.org/3/tutorial/venv.html
- VS Code: Python setup: https://code.visualstudio.com/docs/python/python-tutorial
- Pro Git: recording changes: https://git-scm.com/book/en/v2/Git-Basics-Recording-Changes-to-the-Repository
- GitHub flow: https://docs.github.com/en/get-started/using-github/github-flow
- Python: argparse: https://docs.python.org/3/library/argparse.html
- MIT Missing Semester: https://missing.csail.mit.edu/2026/
