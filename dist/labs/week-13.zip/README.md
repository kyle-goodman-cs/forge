# Week 13: Put a real CLI under version control

This kit starts the checkpoint core. The complete local lab below goes beyond browser checks. Fill in core.py, add your own cases, then build the workflow.

## Setup

Windows PowerShell:
```text
py -m venv .venv
.venv\Scripts\python -m unittest -v
```
macOS/Linux:
```text
python3 -m venv .venv
.venv/bin/python -m unittest -v
```
The included tests start red because the implementation is yours to write. They use only the standard library. Install optional packages such as pytest, Requests, or FastAPI in this environment when the lab calls for them.

## Core challenge
Write exit_result(changes, conflicts, dry_run). Return {"exit_code": 2, "message": "resolve conflicts"} when conflicts > 0. Otherwise return code 0 and "preview N changes" when dry_run is True, or "apply N changes" otherwise.

## Build the full lab
1. Create a fresh .venv and select its interpreter in VS Code.
2. Run python --version and record the supported runtime in README.
3. Create a CLI with --help, --limit, and --dry-run.
4. Initialize Git; create a .gitignore for .venv/, __pycache__/, local data, and secrets.
5. Stage one file, edit it again, and inspect both diff views.
6. Create a feature branch, commit a tested change, and open a practice PR.
7. Record the commit hash and the commands another person needs to run the sample.

## Acceptance criteria
- [ ] A clean environment runs the sample.
- [ ] --help works and invalid numeric input is reported.
- [ ] The staged diff matches the intended change.
- [ ] Your repository has a readable README and no committed secrets.

## Deliverables
- core.py with your implementation
- test_core.py with normal, empty, boundary, and invalid cases where applicable
- README.md with run commands, sample input/output, decisions, and limitations
- Evidence note: what you ran, what failed, what you changed, and help used

## References
- Python: virtual environments: https://docs.python.org/3/tutorial/venv.html
- VS Code: Python setup: https://code.visualstudio.com/docs/python/python-tutorial
- Pro Git: recording changes: https://git-scm.com/book/en/v2/Git-Basics-Recording-Changes-to-the-Repository
- GitHub flow: https://docs.github.com/en/get-started/using-github/github-flow
- Python: argparse: https://docs.python.org/3/library/argparse.html
- MIT Missing Semester: https://missing.csail.mit.edu/2026/
