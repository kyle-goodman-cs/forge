def library_summary(records):
    # Write your solution here
    pass
