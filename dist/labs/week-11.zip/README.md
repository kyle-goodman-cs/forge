# Week 11: Ship the game-library organizer

This kit starts the checkpoint core. The complete local lab below goes beyond browser checks. Fill in core.py, add your own cases, then build the workflow.

## Setup

Windows PowerShell:
```text
py -m venv .venv
.venv\Scripts\python -m unittest -v
```
macOS/Linux:
```text
python3 -m venv .venv
.venv/bin/python -m unittest -v
```
The included tests start red because the implementation is yours to write. They use only the standard library. Install optional packages such as pytest, Requests, or FastAPI in this environment when the lab calls for them.

## Core challenge
Write library_summary(records). Return {"games": number of distinct stripped lowercase titles, "minutes": sum of all minutes}. Each record has title and numeric minutes.

## Build the full lab
1. Write a short spec and three acceptance examples before changing code.
2. Implement import, list, search, and CSV export in a CLI.
3. Keep normalization and aggregation functions in core.py.
4. Save a small synthetic dataset alongside the project.
5. Add tests for duplicates, tags, an empty library, and quoted titles.
6. Verify the README in a clean folder and record a short demo.

## Acceptance criteria
- [ ] All four commands work from documented inputs.
- [ ] Malformed data has a documented outcome.
- [ ] Tests run without manual input.
- [ ] The sample report can be reproduced from the README.

## Deliverables
- core.py with your implementation
- test_core.py with normal, empty, boundary, and invalid cases where applicable
- README.md with run commands, sample input/output, decisions, and limitations
- Evidence note: what you ran, what failed, what you changed, and help used

## References
- Python: modules: https://docs.python.org/3/tutorial/modules.html
- Python: input and output: https://docs.python.org/3/tutorial/inputoutput.html
- Python: csv: https://docs.python.org/3/library/csv.html
- Python: unittest: https://docs.python.org/3/library/unittest.html
