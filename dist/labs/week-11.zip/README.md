# Week 11: Ship the game-library organizer

## Start here

This ZIP is an unfinished checkpoint plus tests. The complete program in the build steps below is yours to create. Passing the supplied tests is only part of the lab.

1. Extract the ZIP into its own folder, for example Documents/Forge Work/week-11.
2. In VS Code, use File > Open Folder to open the folder containing core.py.
3. Choose Terminal > New Terminal. Type the commands below there, not in a .py file.
4. Need help installing Python or using the editor? Return to the Forge browser tab, open chapter 11 in the Quest book, open its independent lab brief, and select First lab? Start guided setup. This works in the local app and the public demo.

## Create the environment (once per lab folder)

Windows PowerShell:
```text
py -m venv .venv
.\.venv\Scripts\python.exe --version
```
macOS/Linux:
```text
python3 -m venv .venv
./.venv/bin/python --version
```
A Python 3 version number confirms the environment works. If Windows has python rather than py, use python -m venv .venv. Select this folder's .venv with VS Code's Python: Select Interpreter command. You do not need to activate it.

## Know the files

- core.py: implement the requested checkpoint function here.
- main.py: build the complete program here, calling functions from core.py as needed. The untouched file only prints a reminder.
- test_core.py: supplied checkpoint tests; add your own tests too.
- cases.json: inputs and expected results used by the supplied tests. Keep these intact.
- README.md: this brief; add your plan, run commands, and sample output here.

## Run tests after saving your files

Windows PowerShell:
```text
.\.venv\Scripts\python.exe -m unittest -v
```
macOS/Linux:
```text
./.venv/bin/python -m unittest -v
```
Expect assertion failures before you implement core.py. They compare the unfinished result with the expected result. An import ERROR or Ran 0 tests needs investigation: make sure the terminal is in the folder containing core.py, test_core.py, and cases.json. OK means the tests that ran passed; you must still check the full lab below. The kit uses built-in unittest, so no extra packages are needed for its tests.

## Run your program

Windows PowerShell:
```text
.\.venv\Scripts\python.exe main.py
```
macOS/Linux:
```text
./.venv/bin/python main.py
```
The untouched main.py is only a starting place. Replace its reminder with your own program. Install extra libraries in .venv only when a later lab needs them.

## Checkpoint contract

Write library_summary(records). Return {"games": number of distinct stripped lowercase titles, "minutes": sum of all minutes}. Each record has title and numeric minutes.

## Build the full lab

1. Write a short spec and three acceptance examples before changing code.
2. Implement import, list, search, and CSV export in a CLI.
3. Keep normalization and aggregation functions in core.py.
4. Save a small synthetic dataset alongside the project.
5. Add tests for duplicates, tags, an empty library, and quoted titles.
6. Verify the README in a clean folder and record a short demo.

## Required GitHub workflow

Before completing your first lab, follow Forge's required GitHub workspace guide from the lab brief. Create one private learning repository, record your setup checklist and repository URL, and keep each chapter folder inside Forge Work. This is separate from the Forge app's source repository.

After the program and tests meet the lab criteria, save all files. From inside week-11, run these commands one at a time. The first moves to Forge Work; the final returns to the chapter folder:

```text
cd ..
git status
git diff -- week-11
git add week-11
git diff --staged
git commit -m "Finish chapter 11 lab"
git push
git status -sb
git rev-parse HEAD
cd week-11
```

Inspect the staged files before committing. A .gitignore does not remove files already tracked. Keep environments, caches, credentials, and unrelated files out of the commit. Use a message describing your actual change. If nothing changed since your previous commit, there may be nothing new to commit; still push any pending commits and verify GitHub's copy.

Refresh your private repository on GitHub and check the latest chapter files and commit. In Forge's lab brief, paste the full commit ID from git rev-parse HEAD and confirm the push. A local commit alone is not a GitHub backup. GitHub setup and pushed-lab evidence are required for new lab completion; Forge records your confirmations rather than independently checking the private repository.


## Acceptance criteria

- [ ] All four commands work from documented inputs.
- [ ] Malformed data has a documented outcome.
- [ ] Tests run without manual input.
- [ ] The sample report can be reproduced from the README.

## Deliverables

- core.py with your implementation
- main.py demonstrating the complete program
- Learning repository URL and a pushed commit ID for this chapter
- test_core.py with normal, empty, boundary, and invalid cases where applicable
- README.md with run commands, sample input/output, decisions, and limitations
- Evidence note: what you ran, what failed, what you changed, and help used

## Evidence to record

Write your example input and expected output before coding. Then record the commands you ran, actual output, a bug you fixed, help used, and anything unfinished. Add at least one test of your own. Check the criteria in Forge after verifying them, and keep a backup of this folder separately from your Forge progress export.

## References

- Python: modules: https://docs.python.org/3/tutorial/modules.html
- Python: input and output: https://docs.python.org/3/tutorial/inputoutput.html
- Python: csv: https://docs.python.org/3/library/csv.html
- Python: unittest: https://docs.python.org/3/library/unittest.html
