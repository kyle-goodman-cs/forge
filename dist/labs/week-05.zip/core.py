def parse_bool(text):
    # Write your solution here
    pass
