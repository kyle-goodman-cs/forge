# Week 5: Build a resilient settings reader

This kit starts the checkpoint core. The complete local lab below goes beyond browser checks. Fill in core.py, add your own cases, then build the workflow.

## Setup

Windows PowerShell:
```text
py -m venv .venv
.venv\Scripts\python -m unittest -v
```
macOS/Linux:
```text
python3 -m venv .venv
.venv/bin/python -m unittest -v
```
The included tests start red because the implementation is yours to write. They use only the standard library. Install optional packages such as pytest, Requests, or FastAPI in this environment when the lab calls for them.

## Core challenge
Write parse_bool(text). After stripping whitespace and lowercasing, return True for "yes", "true", "1"; False for "no", "false", "0"; otherwise None.

## Build the full lab
1. Parse a level, a yes/no flag, and a player name using separate functions.
2. Document valid, invalid, and default behavior for each setting.
3. Capture one failing case before correcting the parser.
4. Add a test for the exact lower and upper limits.
5. Use a debugger breakpoint to inspect a bad input locally.
6. Write a bug note: expected, actual, cause, fix, verification.

## Acceptance criteria
- [ ] Invalid text does not crash the input boundary.
- [ ] Valid zero/False values survive where allowed.
- [ ] Unexpected implementation errors are not silently swallowed.
- [ ] A regression test catches your original bug.

## Deliverables
- core.py with your implementation
- test_core.py with normal, empty, boundary, and invalid cases where applicable
- README.md with run commands, sample input/output, decisions, and limitations
- Evidence note: what you ran, what failed, what you changed, and help used

## References
- Python: errors and exceptions: https://docs.python.org/3/tutorial/errors.html
- Harvard CS50P syllabus: https://cs50.harvard.edu/python/syllabus/
- VS Code: Python setup: https://code.visualstudio.com/docs/python/python-tutorial
