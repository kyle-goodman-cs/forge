# Week 5: Build a resilient settings reader

## Start here

This ZIP is an unfinished checkpoint plus tests. The complete program in the build steps below is yours to create. Passing the supplied tests is only part of the lab.

1. Extract the ZIP into its own folder, for example Documents/Forge Work/week-05.
2. In VS Code, use File > Open Folder to open the folder containing core.py.
3. Choose Terminal > New Terminal. Type the commands below there, not in a .py file.
4. Need help installing Python or using the editor? Open Forge at http://127.0.0.1:8000/#setup/5 for the full guide, expected results, and troubleshooting.

## Create the environment (once per lab folder)

Windows PowerShell:
```text
py -m venv .venv
.\.venv\Scripts\python.exe --version
```
macOS/Linux:
```text
python3 -m venv .venv
./.venv/bin/python --version
```
A Python 3 version number confirms the environment works. If Windows has python rather than py, use python -m venv .venv. Select this folder's .venv with VS Code's Python: Select Interpreter command. You do not need to activate it.

## Know the files

- core.py: implement the requested checkpoint function here.
- main.py: build the complete program here, calling functions from core.py as needed. The untouched file only prints a reminder.
- test_core.py: supplied checkpoint tests; add your own tests too.
- cases.json: inputs and expected results used by the supplied tests. Keep these intact.
- README.md: this brief; add your plan, run commands, and sample output here.

## Run tests after saving your files

Windows PowerShell:
```text
.\.venv\Scripts\python.exe -m unittest -v
```
macOS/Linux:
```text
./.venv/bin/python -m unittest -v
```
Expect assertion failures before you implement core.py. They compare the unfinished result with the expected result. An import ERROR or Ran 0 tests needs investigation: make sure the terminal is in the folder containing core.py, test_core.py, and cases.json. OK means the tests that ran passed; you must still check the full lab below. The kit uses built-in unittest, so no extra packages are needed for its tests.

## Run your program

Windows PowerShell:
```text
.\.venv\Scripts\python.exe main.py
```
macOS/Linux:
```text
./.venv/bin/python main.py
```
The untouched main.py is only a starting place. Replace its reminder with your own program. Install extra libraries in .venv only when a later lab needs them.

## Checkpoint contract

Write parse_bool(text). After stripping whitespace and lowercasing, return True for "yes", "true", "1"; False for "no", "false", "0"; otherwise None.

## Build the full lab

1. Parse a level, a yes/no flag, and a player name using separate functions.
2. Document valid, invalid, and default behavior for each setting.
3. Capture one failing case before correcting the parser.
4. Add a test for the exact lower and upper limits.
5. Use a debugger breakpoint to inspect a bad input locally.
6. Write a bug note: expected, actual, cause, fix, verification.

## Acceptance criteria

- [ ] Invalid text does not crash the input boundary.
- [ ] Valid zero/False values survive where allowed.
- [ ] Unexpected implementation errors are not silently swallowed.
- [ ] A regression test catches your original bug.

## Deliverables

- core.py with your implementation
- main.py demonstrating the complete program
- test_core.py with normal, empty, boundary, and invalid cases where applicable
- README.md with run commands, sample input/output, decisions, and limitations
- Evidence note: what you ran, what failed, what you changed, and help used

## Evidence to record

Write your example input and expected output before coding. Then record the commands you ran, actual output, a bug you fixed, help used, and anything unfinished. Add at least one test of your own. Check the criteria in Forge after verifying them, and keep a backup of this folder separately from your Forge progress export.

## References

- Python: errors and exceptions: https://docs.python.org/3/tutorial/errors.html
- Harvard CS50P syllabus: https://cs50.harvard.edu/python/syllabus/
- VS Code: Python setup: https://code.visualstudio.com/docs/python/python-tutorial
