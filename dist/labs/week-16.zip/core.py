def sql_lookup(titles, wanted):
    # Plan, implement, then run the checks.
    pass
