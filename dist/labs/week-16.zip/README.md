# Week 16: Persist the game library in SQLite

This kit starts the checkpoint core. The complete local lab below goes beyond browser checks. Fill in core.py, add your own cases, then build the workflow.

## Setup

Windows PowerShell:
```text
py -m venv .venv
.venv\Scripts\python -m unittest -v
```
macOS/Linux:
```text
python3 -m venv .venv
.venv/bin/python -m unittest -v
```
The included tests start red because the implementation is yours to write. They use only the standard library. Install optional packages such as pytest, Requests, or FastAPI in this environment when the lab calls for them.

## Core challenge
Write sql_lookup(titles, wanted). Store the supplied titles in a games(title TEXT) table and return the count of exact title matches using a parameterized WHERE query. Titles may contain quotes or SQL-looking text.

## Build the full lab
1. Create games and sessions tables with primary/foreign keys and a documented schema.
2. Add parameterized insert and search functions.
3. Implement a joined total report including games with zero sessions.
4. Test quotes and SQL-looking input as literal values.
5. Use a transaction for an operation that inserts related data.
6. Force a failure and verify rollback.
7. Close and reopen the file database to prove persistence.

## Acceptance criteria
- [ ] Literal quote-containing titles work.
- [ ] Reports include zero-session games and deterministic ordering.
- [ ] A failed multi-step update leaves no partial result.
- [ ] Tests use a temporary database and leave real data untouched.

## Deliverables
- core.py with your implementation
- test_core.py with normal, empty, boundary, and invalid cases where applicable
- README.md with run commands, sample input/output, decisions, and limitations
- Evidence note: what you ran, what failed, what you changed, and help used

## References
- W3Schools: SQL introduction: https://www.w3schools.com/sql/sql_intro.asp
- Python: sqlite3: https://docs.python.org/3/library/sqlite3.html
