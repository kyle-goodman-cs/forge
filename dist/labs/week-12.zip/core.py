def recommend(games, budget):
    # Write your solution here
    pass
