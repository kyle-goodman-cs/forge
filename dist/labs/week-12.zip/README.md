# Week 12: Independent mini-build

## Start here

This ZIP is an unfinished checkpoint plus tests. The complete program in the build steps below is yours to create. Passing the supplied tests is only part of the lab.

1. Extract the ZIP into its own folder, for example Documents/Forge Work/week-12.
2. In VS Code, use File > Open Folder to open the folder containing core.py.
3. Choose Terminal > New Terminal. Type the commands below there, not in a .py file.
4. Need help installing Python or using the editor? Open Forge at http://127.0.0.1:8000/#setup/12 for the full guide, expected results, and troubleshooting.

## Create the environment (once per lab folder)

Windows PowerShell:
```text
py -m venv .venv
.\.venv\Scripts\python.exe --version
```
macOS/Linux:
```text
python3 -m venv .venv
./.venv/bin/python --version
```
A Python 3 version number confirms the environment works. If Windows has python rather than py, use python -m venv .venv. Select this folder's .venv with VS Code's Python: Select Interpreter command. You do not need to activate it.

## Know the files

- core.py: implement the requested checkpoint function here.
- main.py: build the complete program here, calling functions from core.py as needed. The untouched file only prints a reminder.
- test_core.py: supplied checkpoint tests; add your own tests too.
- cases.json: inputs and expected results used by the supplied tests. Keep these intact.
- README.md: this brief; add your plan, run commands, and sample output here.

## Run tests after saving your files

Windows PowerShell:
```text
.\.venv\Scripts\python.exe -m unittest -v
```
macOS/Linux:
```text
./.venv/bin/python -m unittest -v
```
Expect assertion failures before you implement core.py. They compare the unfinished result with the expected result. An import ERROR or Ran 0 tests needs investigation: make sure the terminal is in the folder containing core.py, test_core.py, and cases.json. OK means the tests that ran passed; you must still check the full lab below. The kit uses built-in unittest, so no extra packages are needed for its tests.

## Run your program

Windows PowerShell:
```text
.\.venv\Scripts\python.exe main.py
```
macOS/Linux:
```text
./.venv/bin/python main.py
```
The untouched main.py is only a starting place. Replace its reminder with your own program. Install extra libraries in .venv only when a later lab needs them.

## Checkpoint contract

Write recommend(games, budget). Each game has title, price, rating. Keep games priced <= budget. Return up to 3 titles ranked by rating descending, then price ascending, then title alphabetically. Do not change the input list.

## Build the full lab

1. Choose a tournament table, playtime analyzer, or game recommender.
2. Write a spec without referring to a solution.
3. Create a clean module and implement the smallest useful version.
4. Write normal, empty, invalid, and tie/boundary tests.
5. Explain one tradeoff and one limitation in the README.
6. After a few days, change a requirement and implement the variation without a walkthrough.

## Acceptance criteria

- [ ] The original spec and sample outputs agree.
- [ ] Tests demonstrate the documented boundaries.
- [ ] You can explain every function.
- [ ] You record help used and a next practice target.

## Deliverables

- core.py with your implementation
- main.py demonstrating the complete program
- test_core.py with normal, empty, boundary, and invalid cases where applicable
- README.md with run commands, sample input/output, decisions, and limitations
- Evidence note: what you ran, what failed, what you changed, and help used

## Evidence to record

Write your example input and expected output before coding. Then record the commands you ran, actual output, a bug you fixed, help used, and anything unfinished. Add at least one test of your own. Check the criteria in Forge after verifying them, and keep a backup of this folder separately from your Forge progress export.

## References

- Harvard CS50P syllabus: https://cs50.harvard.edu/python/syllabus/
- Official Python tutorial: https://docs.python.org/3/tutorial/
- Python: unittest: https://docs.python.org/3/library/unittest.html
