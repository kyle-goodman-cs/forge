# Week 12: Independent mini-build

This kit starts the checkpoint core. The complete local lab below goes beyond browser checks. Fill in core.py, add your own cases, then build the workflow.

## Setup

Windows PowerShell:
```text
py -m venv .venv
.venv\Scripts\python -m unittest -v
```
macOS/Linux:
```text
python3 -m venv .venv
.venv/bin/python -m unittest -v
```
The included tests start red because the implementation is yours to write. They use only the standard library. Install optional packages such as pytest, Requests, or FastAPI in this environment when the lab calls for them.

## Core challenge
Write recommend(games, budget). Each game has title, price, rating. Keep games priced <= budget. Return up to 3 titles ranked by rating descending, then price ascending, then title alphabetically. Do not change the input list.

## Build the full lab
1. Choose a tournament table, playtime analyzer, or game recommender.
2. Write a spec without referring to a solution.
3. Create a clean module and implement the smallest useful version.
4. Write normal, empty, invalid, and tie/boundary tests.
5. Explain one tradeoff and one limitation in the README.
6. After a few days, change a requirement and implement the variation without a walkthrough.

## Acceptance criteria
- [ ] The original spec and sample outputs agree.
- [ ] Tests demonstrate the documented boundaries.
- [ ] You can explain every function.
- [ ] You record help used and a next practice target.

## Deliverables
- core.py with your implementation
- test_core.py with normal, empty, boundary, and invalid cases where applicable
- README.md with run commands, sample input/output, decisions, and limitations
- Evidence note: what you ran, what failed, what you changed, and help used

## References
- Harvard CS50P syllabus: https://cs50.harvard.edu/python/syllabus/
- Official Python tutorial: https://docs.python.org/3/tutorial/
- Python: unittest: https://docs.python.org/3/library/unittest.html
