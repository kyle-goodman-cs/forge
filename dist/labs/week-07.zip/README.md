# Week 7: Create a read-only rename preview

This kit starts the checkpoint core. The complete local lab below goes beyond browser checks. Fill in core.py, add your own cases, then build the workflow.

## Setup

Windows PowerShell:
```text
py -m venv .venv
.venv\Scripts\python -m unittest -v
```
macOS/Linux:
```text
python3 -m venv .venv
.venv/bin/python -m unittest -v
```
The included tests start red because the implementation is yours to write. They use only the standard library. Install optional packages such as pytest, Requests, or FastAPI in this environment when the lab calls for them.

## Core challenge
Write audit(plan). Return {"changes": number of pairs, "conflicts": number of distinct repeated target names}. Each pair is [source, target].

## Build the full lab
1. Make a disposable sample folder with names containing spaces and case differences.
2. Generate a rename plan without calling rename or writing files.
3. Detect repeated target names and targets already occupied by unchanged files.
4. Print old → new mappings and an audit count.
5. Test a clean plan, a collision, and an already-normalized folder.
6. Keep execution out of this lab; add it only after your preview is reliable.

## Acceptance criteria
- [ ] Preview performs no writes.
- [ ] A collision blocks the proposed batch.
- [ ] A second normalization of clean names produces no changes.
- [ ] Platform and case-sensitivity assumptions are documented.

## Deliverables
- core.py with your implementation
- test_core.py with normal, empty, boundary, and invalid cases where applicable
- README.md with run commands, sample input/output, decisions, and limitations
- Evidence note: what you ran, what failed, what you changed, and help used

## References
- Python: pathlib: https://docs.python.org/3/library/pathlib.html
- Python: data structures: https://docs.python.org/3/tutorial/datastructures.html
- Python: argparse: https://docs.python.org/3/library/argparse.html
