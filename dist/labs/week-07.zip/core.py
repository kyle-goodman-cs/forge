def audit(plan):
    # Write your solution here
    pass
