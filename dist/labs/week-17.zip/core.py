def retry_delays(statuses):
    # Plan, implement, then run the checks.
    pass
