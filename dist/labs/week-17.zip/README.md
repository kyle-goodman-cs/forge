# Week 17: Build an offline-first API client

This kit starts the checkpoint core. The complete local lab below goes beyond browser checks. Fill in core.py, add your own cases, then build the workflow.

## Setup

Windows PowerShell:
```text
py -m venv .venv
.venv\Scripts\python -m unittest -v
```
macOS/Linux:
```text
python3 -m venv .venv
.venv/bin/python -m unittest -v
```
The included tests start red because the implementation is yours to write. They use only the standard library. Install optional packages such as pytest, Requests, or FastAPI in this environment when the lab calls for them.

## Core challenge
Write retry_delays(statuses). Inspect sequential attempt status codes. Stop at the first 2xx success or a nonretryable code. After each retryable 429 or 5xx failure, add a delay of 1, 2, 4, ... seconds, but add no delay after the final supplied attempt. Return the delay list.

## Build the full lab
1. Define a fixture response with items and a next token.
2. Implement transformation independently of the HTTP library.
3. Test success, error status, invalid JSON/schema, overlapping pages, and a repeated token.
4. Add a Requests adapter locally with explicit timeout handling.
5. Keep base URL and any secret token outside core logic and committed source.
6. Document rate limits and the retry policy.
7. Use the fixture mode as the default reproducible demo; optionally show one live request.

## Acceptance criteria
- [ ] Fixture tests pass without a network.
- [ ] Pagination and retries have hard limits.
- [ ] A failed page produces a visible, documented outcome.
- [ ] No credentials appear in source or logs.

## Deliverables
- core.py with your implementation
- test_core.py with normal, empty, boundary, and invalid cases where applicable
- README.md with run commands, sample input/output, decisions, and limitations
- Evidence note: what you ran, what failed, what you changed, and help used

## References
- MDN: HTTP overview: https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Overview
- Requests quickstart: https://requests.readthedocs.io/en/latest/user/quickstart/
- Python: input and output: https://docs.python.org/3/tutorial/inputoutput.html
