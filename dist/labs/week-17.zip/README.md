# Week 17: Build an offline-first API client

## Start here

This ZIP is an unfinished checkpoint plus tests. The complete program in the build steps below is yours to create. Passing the supplied tests is only part of the lab.

1. Extract the ZIP into its own folder, for example Documents/Forge Work/week-17.
2. In VS Code, use File > Open Folder to open the folder containing core.py.
3. Choose Terminal > New Terminal. Type the commands below there, not in a .py file.
4. Need help installing Python or using the editor? Open Forge at http://127.0.0.1:8000/#setup/17 for the full guide, expected results, and troubleshooting.

## Create the environment (once per lab folder)

Windows PowerShell:
```text
py -m venv .venv
.\.venv\Scripts\python.exe --version
```
macOS/Linux:
```text
python3 -m venv .venv
./.venv/bin/python --version
```
A Python 3 version number confirms the environment works. If Windows has python rather than py, use python -m venv .venv. Select this folder's .venv with VS Code's Python: Select Interpreter command. You do not need to activate it.

## Know the files

- core.py: implement the requested checkpoint function here.
- main.py: build the complete program here, calling functions from core.py as needed. The untouched file only prints a reminder.
- test_core.py: supplied checkpoint tests; add your own tests too.
- cases.json: inputs and expected results used by the supplied tests. Keep these intact.
- README.md: this brief; add your plan, run commands, and sample output here.

## Run tests after saving your files

Windows PowerShell:
```text
.\.venv\Scripts\python.exe -m unittest -v
```
macOS/Linux:
```text
./.venv/bin/python -m unittest -v
```
Expect assertion failures before you implement core.py. They compare the unfinished result with the expected result. An import ERROR or Ran 0 tests needs investigation: make sure the terminal is in the folder containing core.py, test_core.py, and cases.json. OK means the tests that ran passed; you must still check the full lab below. The kit uses built-in unittest, so no extra packages are needed for its tests.

## Run your program

Windows PowerShell:
```text
.\.venv\Scripts\python.exe main.py
```
macOS/Linux:
```text
./.venv/bin/python main.py
```
The untouched main.py is only a starting place. Replace its reminder with your own program. Install extra libraries in .venv only when a later lab needs them.

## Checkpoint contract

Write retry_delays(statuses). Inspect sequential attempt status codes. Stop at the first 2xx success or a nonretryable code. After each retryable 429 or 5xx failure, add a delay of 1, 2, 4, ... seconds, but add no delay after the final supplied attempt. Return the delay list.

## Build the full lab

1. Define a fixture response with items and a next token.
2. Implement transformation independently of the HTTP library.
3. Test success, error status, invalid JSON/schema, overlapping pages, and a repeated token.
4. Add a Requests adapter locally with explicit timeout handling.
5. Keep base URL and any secret token outside core logic and committed source.
6. Document rate limits and the retry policy.
7. Use the fixture mode as the default reproducible demo; optionally show one live request.

## Acceptance criteria

- [ ] Fixture tests pass without a network.
- [ ] Pagination and retries have hard limits.
- [ ] A failed page produces a visible, documented outcome.
- [ ] No credentials appear in source or logs.

## Deliverables

- core.py with your implementation
- main.py demonstrating the complete program
- test_core.py with normal, empty, boundary, and invalid cases where applicable
- README.md with run commands, sample input/output, decisions, and limitations
- Evidence note: what you ran, what failed, what you changed, and help used

## Evidence to record

Write your example input and expected output before coding. Then record the commands you ran, actual output, a bug you fixed, help used, and anything unfinished. Add at least one test of your own. Check the criteria in Forge after verifying them, and keep a backup of this folder separately from your Forge progress export.

## References

- MDN: HTTP overview: https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Overview
- Requests quickstart: https://requests.readthedocs.io/en/latest/user/quickstart/
- Python: input and output: https://docs.python.org/3/tutorial/inputoutput.html
