# Build the full lab here. Keep reusable rules in core.py.
# Replace this reminder with your own program.
print("Starter ready. Read README.md and build your lab in this file.")
