def first_nonempty(values):
    # Plan, implement, then run the checks.
    pass
