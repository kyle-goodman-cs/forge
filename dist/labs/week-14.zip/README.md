# Week 14: Fix a bug with a regression test

This kit starts the checkpoint core. The complete local lab below goes beyond browser checks. Fill in core.py, add your own cases, then build the workflow.

## Setup

Windows PowerShell:
```text
py -m venv .venv
.venv\Scripts\python -m unittest -v
```
macOS/Linux:
```text
python3 -m venv .venv
.venv/bin/python -m unittest -v
```
The included tests start red because the implementation is yours to write. They use only the standard library. Install optional packages such as pytest, Requests, or FastAPI in this environment when the lab calls for them.

## Core challenge
Write first_nonempty(values). Return the first element that is neither None nor the empty string. Values such as 0, False, and [] must be preserved. Return None if no element qualifies.

## Build the full lab
1. Create a small cache or parser module with a deliberate falsy-value bug.
2. Write a failing unit test before fixing it.
3. Use a debugger breakpoint to inspect the bad decision.
4. Make the smallest coherent correction and run the entire suite.
5. Add one fake dependency and verify both hit and miss behavior.
6. Add type hints and docstrings to the public function.
7. Write a short change description including reproduction and test commands.

## Acceptance criteria
- [ ] The original buggy version fails your regression test.
- [ ] The corrected version passes all relevant tests.
- [ ] Unit tests do not depend on a live network.
- [ ] Public inputs, results, errors, and side effects are documented.

## Deliverables
- core.py with your implementation
- test_core.py with normal, empty, boundary, and invalid cases where applicable
- README.md with run commands, sample input/output, decisions, and limitations
- Evidence note: what you ran, what failed, what you changed, and help used

## References
- pytest: getting started: https://docs.pytest.org/en/stable/getting-started.html
- Python: unittest: https://docs.python.org/3/library/unittest.html
- Python: errors and exceptions: https://docs.python.org/3/tutorial/errors.html
- Python: typing: https://docs.python.org/3/library/typing.html
- VS Code: Python setup: https://code.visualstudio.com/docs/python/python-tutorial
