def validate_rows(rows):
    # Plan, implement, then run the checks.
    pass
