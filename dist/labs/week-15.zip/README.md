# Week 15: Import a deliberately messy dataset

This kit starts the checkpoint core. The complete local lab below goes beyond browser checks. Fill in core.py, add your own cases, then build the workflow.

## Setup

Windows PowerShell:
```text
py -m venv .venv
.venv\Scripts\python -m unittest -v
```
macOS/Linux:
```text
python3 -m venv .venv
.venv/bin/python -m unittest -v
```
The included tests start red because the implementation is yours to write. They use only the standard library. Install optional packages such as pytest, Requests, or FastAPI in this environment when the lab calls for them.

## Core challenge
Write validate_rows(rows). Each row is a dictionary. Accept when name is a nonempty stripped string and minutes is an int >= 0 (booleans do not count as ints). Return {"accepted": count, "rejected": zero-based indices}.

## Build the full lab
1. Create valid records, missing fields, invalid types, a leap-day date, and a malformed identifier.
2. Write independent parsers for ticket id, date, and price.
3. Normalize only after validating types.
4. Write accepted and rejected outputs with row positions and reasons.
5. Keep money as cents and document timezone/date assumptions.
6. Test every rejection rule and reconcile input/output counts.

## Acceptance criteria
- [ ] Accepted plus rejected rows equal the input count.
- [ ] Invalid dates and types are reported predictably.
- [ ] Currency output has no float rounding surprise.
- [ ] The rejected report identifies how to repair a row.

## Deliverables
- core.py with your implementation
- test_core.py with normal, empty, boundary, and invalid cases where applicable
- README.md with run commands, sample input/output, decisions, and limitations
- Evidence note: what you ran, what failed, what you changed, and help used

## References
- Python: regular expressions: https://docs.python.org/3/library/re.html
- Python: datetime: https://docs.python.org/3/library/datetime.html
- Python: errors and exceptions: https://docs.python.org/3/tutorial/errors.html
- Python: csv: https://docs.python.org/3/library/csv.html
