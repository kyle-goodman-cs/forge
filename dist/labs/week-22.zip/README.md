# Week 22: Complete a maintenance ticket

This kit starts the checkpoint core. The complete local lab below goes beyond browser checks. Fill in core.py, add your own cases, then build the workflow.

## Setup

Windows PowerShell:
```text
py -m venv .venv
.venv\Scripts\python -m unittest -v
```
macOS/Linux:
```text
python3 -m venv .venv
.venv/bin/python -m unittest -v
```
The included tests start red because the implementation is yours to write. They use only the standard library. Install optional packages such as pytest, Requests, or FastAPI in this environment when the lab calls for them.

## Core challenge
Write triage(previous, current). Lists contain failing test names. Return {"new": sorted newly failing names, "resolved": sorted formerly failing names now passing, "still_failing": sorted shared names}. Deduplicate all names.

## Build the full lab
1. Use an earlier project or a small openly available repository you can run.
2. Write a code map and reproduce a specific bug.
3. Create a branch and a regression test.
4. Implement an adapter or focused fix without unrelated cleanup.
5. Review the diff and run the complete relevant test suite.
6. Write a PR description and a short handoff with reproduction steps.
7. Create and resolve a practice conflict in your own repo, then verify behavior again.

## Acceptance criteria
- [ ] The bug is reproducible before the change.
- [ ] Tests prove the corrected behavior and retained compatibility.
- [ ] The diff is focused and understandable.
- [ ] The handoff distinguishes known evidence and remaining uncertainty.

## Deliverables
- core.py with your implementation
- test_core.py with normal, empty, boundary, and invalid cases where applicable
- README.md with run commands, sample input/output, decisions, and limitations
- Evidence note: what you ran, what failed, what you changed, and help used

## References
- Pro Git: recording changes: https://git-scm.com/book/en/v2/Git-Basics-Recording-Changes-to-the-Repository
- GitHub flow: https://docs.github.com/en/get-started/using-github/github-flow
- Python: modules: https://docs.python.org/3/tutorial/modules.html
- pytest: getting started: https://docs.pytest.org/en/stable/getting-started.html
