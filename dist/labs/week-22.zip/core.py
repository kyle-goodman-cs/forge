def triage(previous, current):
    # Plan, implement, then run the checks.
    pass
