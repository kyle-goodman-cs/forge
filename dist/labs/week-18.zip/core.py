def merge_config(defaults, file_settings, cli_settings):
    # Plan, implement, then run the checks.
    pass
