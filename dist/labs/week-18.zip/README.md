# Week 18: Refactor without changing behavior

This kit starts the checkpoint core. The complete local lab below goes beyond browser checks. Fill in core.py, add your own cases, then build the workflow.

## Setup

Windows PowerShell:
```text
py -m venv .venv
.venv\Scripts\python -m unittest -v
```
macOS/Linux:
```text
python3 -m venv .venv
.venv/bin/python -m unittest -v
```
The included tests start red because the implementation is yours to write. They use only the standard library. Install optional packages such as pytest, Requests, or FastAPI in this environment when the lab calls for them.

## Core challenge
Write merge_config(defaults, file_settings, cli_settings). Return a new dictionary with CLI keys overriding file keys and file keys overriding defaults. Preserve explicit None, False, and 0. Do not mutate the inputs.

## Build the full lab
1. Choose an earlier CLI with a long main file.
2. Write regression tests for its public behavior.
3. Split parsing, core rules, storage, and presentation into modules.
4. Add an injectable repository or fetcher where I/O was hard-coded.
5. Use a validated settings record and document precedence.
6. Demonstrate a generator for streaming input only where it simplifies the design.
7. Run the same tests and compare the CLI output before and after.

## Acceptance criteria
- [ ] Public behavior is preserved by regression tests.
- [ ] Importing core modules performs no writes or prompts.
- [ ] State is isolated across calls and instances.
- [ ] A README explains the new module map.

## Deliverables
- core.py with your implementation
- test_core.py with normal, empty, boundary, and invalid cases where applicable
- README.md with run commands, sample input/output, decisions, and limitations
- Evidence note: what you ran, what failed, what you changed, and help used

## References
- Python: control flow and functions: https://docs.python.org/3/tutorial/controlflow.html
- Python: modules: https://docs.python.org/3/tutorial/modules.html
- Python: classes: https://docs.python.org/3/tutorial/classes.html
- Python: dataclasses: https://docs.python.org/3/library/dataclasses.html
- Python: typing: https://docs.python.org/3/library/typing.html
