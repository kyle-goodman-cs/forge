def count_wins(scores, target):
    # Write your solution here
    pass
