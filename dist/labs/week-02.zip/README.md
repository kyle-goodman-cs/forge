# Week 2: Create a score-filter report

This kit starts the checkpoint core. The complete local lab below goes beyond browser checks. Fill in core.py, add your own cases, then build the workflow.

## Setup

Windows PowerShell:
```text
py -m venv .venv
.venv\Scripts\python -m unittest -v
```
macOS/Linux:
```text
python3 -m venv .venv
.venv/bin/python -m unittest -v
```
The included tests start red because the implementation is yours to write. They use only the standard library. Install optional packages such as pytest, Requests, or FastAPI in this environment when the lab calls for them.

## Core challenge
Write count_wins(scores, target). Count how many scores are >= target. Return an integer, not a list.

## Build the full lab
1. Write a function that keeps scores meeting a threshold.
2. Write another function that counts them using a loop.
3. Add a formatter that creates a human-readable report using an f-string.
4. Test an empty list, equal-to-threshold scores, and a list with no matches.
5. Trace one failing case in a table with item, condition, and accumulator columns.
6. Refactor one loop to a comprehension only after both versions pass the same tests.

## Acceptance criteria
- [ ] Input order is preserved where the contract requires it.
- [ ] The original scores list remains unchanged.
- [ ] Count and list agree on the number of matches.
- [ ] You can explain an entire loop trace.

## Deliverables
- core.py with your implementation
- test_core.py with normal, empty, boundary, and invalid cases where applicable
- README.md with run commands, sample input/output, decisions, and limitations
- Evidence note: what you ran, what failed, what you changed, and help used

## References
- Python: numbers, strings, and lists: https://docs.python.org/3/tutorial/introduction.html
- Python: control flow and functions: https://docs.python.org/3/tutorial/controlflow.html
- Python: data structures: https://docs.python.org/3/tutorial/datastructures.html
