def loot_counts(items):
    # Write your solution here
    pass
