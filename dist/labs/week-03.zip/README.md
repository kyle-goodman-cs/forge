# Week 3: Inventory and leaderboard

This kit starts the checkpoint core. The complete local lab below goes beyond browser checks. Fill in core.py, add your own cases, then build the workflow.

## Setup

Windows PowerShell:
```text
py -m venv .venv
.venv\Scripts\python -m unittest -v
```
macOS/Linux:
```text
python3 -m venv .venv
.venv/bin/python -m unittest -v
```
The included tests start red because the implementation is yours to write. They use only the standard library. Install optional packages such as pytest, Requests, or FastAPI in this environment when the lab calls for them.

## Core challenge
Write loot_counts(items), returning a dictionary mapping each item string to its number of occurrences.

## Build the full lab
1. Represent an inventory with item → count.
2. Implement add, remove, and a deterministic display order.
3. Keep a history of sample loot drops and aggregate their frequencies.
4. Build a leaderboard with an explicit tie rule.
5. Test a missing item, repeated items, ties, and empty input.
6. Use a copy when the spec promises not to mutate caller data.

## Acceptance criteria
- [ ] Missing-item behavior is documented.
- [ ] Sorting ties match the stated policy.
- [ ] Input data remains unchanged for pure functions.
- [ ] You can justify each chosen collection.

## Deliverables
- core.py with your implementation
- test_core.py with normal, empty, boundary, and invalid cases where applicable
- README.md with run commands, sample input/output, decisions, and limitations
- Evidence note: what you ran, what failed, what you changed, and help used

## References
- Python: data structures: https://docs.python.org/3/tutorial/datastructures.html
- Python: collections: https://docs.python.org/3/library/collections.html
- W3Schools Python syllabus: https://www.w3schools.com/python/python_syllabus.asp
