def recent_activity(rows, limit):
    # Plan, implement, then run the checks.
    pass
