# Week 24: Complete an honest entry-level rehearsal

This kit starts the checkpoint core. The complete local lab below goes beyond browser checks. Fill in core.py, add your own cases, then build the workflow.

## Setup

Windows PowerShell:
```text
py -m venv .venv
.venv\Scripts\python -m unittest -v
```
macOS/Linux:
```text
python3 -m venv .venv
.venv/bin/python -m unittest -v
```
The included tests start red because the implementation is yours to write. They use only the standard library. Install optional packages such as pytest, Requests, or FastAPI in this environment when the lab calls for them.

## Core challenge
Write recent_activity(rows, limit). Valid rows have string user (nonempty after stripping) and integer timestamp >= 0 (exclude bool). Keep each normalized lowercase user’s largest timestamp. Return up to limit user names sorted by timestamp descending, then name ascending. Return [] for limit <= 0. Ignore invalid rows.

## Build the full lab
1. Choose an unfamiliar small task and record the spec and assumptions.
2. Spend 60–90 minutes implementing, testing, and documenting a coherent version.
3. Complete an existing-code bug fix using a failing regression test.
4. Write three SQL queries including a join and an aggregate.
5. Create a focused Git branch and practice PR.
6. Explain one project and one complexity tradeoff aloud.
7. Use evidence in the readiness rubric to select next week’s weakest skill.

## Acceptance criteria
- [ ] Unseen implementation matches the stated acceptance cases.
- [ ] The bug fix is demonstrated by a failing-then-passing test.
- [ ] SQL, Git, and project handoff work independently.
- [ ] Your evidence notes identify remaining gaps and outside help.

## Deliverables
- core.py with your implementation
- test_core.py with normal, empty, boundary, and invalid cases where applicable
- README.md with run commands, sample input/output, decisions, and limitations
- Evidence note: what you ran, what failed, what you changed, and help used

## References
- Harvard CS50P syllabus: https://cs50.harvard.edu/python/syllabus/
- MIT Missing Semester: https://missing.csail.mit.edu/2026/
- pytest: getting started: https://docs.pytest.org/en/stable/getting-started.html
- Pro Git: recording changes: https://git-scm.com/book/en/v2/Git-Basics-Recording-Changes-to-the-Repository
- Python: sqlite3: https://docs.python.org/3/library/sqlite3.html
