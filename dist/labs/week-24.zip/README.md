# Week 24: Complete an honest entry-level rehearsal

## Start here

This ZIP is an unfinished checkpoint plus tests. The complete program in the build steps below is yours to create. Passing the supplied tests is only part of the lab.

1. Extract the ZIP into its own folder, for example Documents/Forge Work/week-24.
2. In VS Code, use File > Open Folder to open the folder containing core.py.
3. Choose Terminal > New Terminal. Type the commands below there, not in a .py file.
4. Need help installing Python or using the editor? Return to the Forge browser tab, open chapter 24 in the Quest book, open its independent lab brief, and select First lab? Start guided setup. This works in the local app and the public demo.

## Create the environment (once per lab folder)

Windows PowerShell:
```text
py -m venv .venv
.\.venv\Scripts\python.exe --version
```
macOS/Linux:
```text
python3 -m venv .venv
./.venv/bin/python --version
```
A Python 3 version number confirms the environment works. If Windows has python rather than py, use python -m venv .venv. Select this folder's .venv with VS Code's Python: Select Interpreter command. You do not need to activate it.

## Know the files

- core.py: implement the requested checkpoint function here.
- main.py: build the complete program here, calling functions from core.py as needed. The untouched file only prints a reminder.
- test_core.py: supplied checkpoint tests; add your own tests too.
- cases.json: inputs and expected results used by the supplied tests. Keep these intact.
- README.md: this brief; add your plan, run commands, and sample output here.

## Run tests after saving your files

Windows PowerShell:
```text
.\.venv\Scripts\python.exe -m unittest -v
```
macOS/Linux:
```text
./.venv/bin/python -m unittest -v
```
Expect assertion failures before you implement core.py. They compare the unfinished result with the expected result. An import ERROR or Ran 0 tests needs investigation: make sure the terminal is in the folder containing core.py, test_core.py, and cases.json. OK means the tests that ran passed; you must still check the full lab below. The kit uses built-in unittest, so no extra packages are needed for its tests.

## Run your program

Windows PowerShell:
```text
.\.venv\Scripts\python.exe main.py
```
macOS/Linux:
```text
./.venv/bin/python main.py
```
The untouched main.py is only a starting place. Replace its reminder with your own program. Install extra libraries in .venv only when a later lab needs them.

## Checkpoint contract

Write recent_activity(rows, limit). Valid rows have string user (nonempty after stripping) and integer timestamp >= 0 (exclude bool). Keep each normalized lowercase user’s largest timestamp. Return up to limit user names sorted by timestamp descending, then name ascending. Return [] for limit <= 0. Ignore invalid rows.

## Build the full lab

1. Choose an unfamiliar small task and record the spec and assumptions.
2. Spend 60–90 minutes implementing, testing, and documenting a coherent version.
3. Complete an existing-code bug fix using a failing regression test.
4. Write three SQL queries including a join and an aggregate.
5. Create a focused Git branch and practice PR.
6. Explain one project and one complexity tradeoff aloud.
7. Use evidence in the readiness rubric to select next week’s weakest skill.

## Required GitHub workflow

Before completing your first lab, follow Forge's required GitHub workspace guide from the lab brief. Create one private learning repository, record your setup checklist and repository URL, and keep each chapter folder inside Forge Work. This is separate from the Forge app's source repository.

After the program and tests meet the lab criteria, save all files. From inside week-24, run these commands one at a time. The first moves to Forge Work; the final returns to the chapter folder:

```text
cd ..
git status
git diff -- week-24
git add week-24
git diff --staged
git commit -m "Finish chapter 24 lab"
git push
git status -sb
git rev-parse HEAD
cd week-24
```

Inspect the staged files before committing. A .gitignore does not remove files already tracked. Keep environments, caches, credentials, and unrelated files out of the commit. Use a message describing your actual change. If nothing changed since your previous commit, there may be nothing new to commit; still push any pending commits and verify GitHub's copy.

Refresh your private repository on GitHub and check the latest chapter files and commit. In Forge's lab brief, paste the full commit ID from git rev-parse HEAD and confirm the push. A local commit alone is not a GitHub backup. GitHub setup and pushed-lab evidence are required for new lab completion; Forge records your confirmations rather than independently checking the private repository.


## Acceptance criteria

- [ ] Unseen implementation matches the stated acceptance cases.
- [ ] The bug fix is demonstrated by a failing-then-passing test.
- [ ] SQL, Git, and project handoff work independently.
- [ ] Your evidence notes identify remaining gaps and outside help.

## Deliverables

- core.py with your implementation
- main.py demonstrating the complete program
- Learning repository URL and a pushed commit ID for this chapter
- test_core.py with normal, empty, boundary, and invalid cases where applicable
- README.md with run commands, sample input/output, decisions, and limitations
- Evidence note: what you ran, what failed, what you changed, and help used

## Evidence to record

Write your example input and expected output before coding. Then record the commands you ran, actual output, a bug you fixed, help used, and anything unfinished. Add at least one test of your own. Check the criteria in Forge after verifying them, and keep a backup of this folder separately from your Forge progress export.

## References

- Harvard CS50P syllabus: https://cs50.harvard.edu/python/syllabus/
- MIT Missing Semester: https://missing.csail.mit.edu/2026/
- pytest: getting started: https://docs.pytest.org/en/stable/getting-started.html
- Pro Git: recording changes: https://git-scm.com/book/en/v2/Git-Basics-Recording-Changes-to-the-Repository
- Python: sqlite3: https://docs.python.org/3/library/sqlite3.html
