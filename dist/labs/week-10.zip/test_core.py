import json
import unittest
from pathlib import Path
from core import best_players

class CoreTests(unittest.TestCase):
    def test_supplied_cases(self):
        cases = json.loads(Path(__file__).with_name("cases.json").read_text(encoding="utf-8"))
        for case in cases:
            with self.subTest(args=case["args"]):
                self.assertEqual(best_players(*case["args"]), case["expected"])

    # Add your own boundary and invalid cases based on the contract.

if __name__ == "__main__":
    unittest.main()
