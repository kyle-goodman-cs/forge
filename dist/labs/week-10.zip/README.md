# Week 10: Score service with a clear interface

This kit starts the checkpoint core. The complete local lab below goes beyond browser checks. Fill in core.py, add your own cases, then build the workflow.

## Setup

Windows PowerShell:
```text
py -m venv .venv
.venv\Scripts\python -m unittest -v
```
macOS/Linux:
```text
python3 -m venv .venv
.venv/bin/python -m unittest -v
```
The included tests start red because the implementation is yours to write. They use only the standard library. Install optional packages such as pytest, Requests, or FastAPI in this environment when the lab calls for them.

## Core challenge
Write best_players(records). Each record has name and score. Keep each player’s highest score, then return names ordered by descending best score with alphabetical ties.

## Build the full lab
1. Model scores as data with a documented update policy.
2. Implement best-score updates and deterministic ranking.
3. Keep storage outside the scoring calculation.
4. Test two independent player instances if you use a class.
5. Document tie rules, invalid inputs, and whether updates mutate state.
6. Refactor one long function into small named steps while preserving tests.

## Acceptance criteria
- [ ] State is not unintentionally shared.
- [ ] Ranking ties match the contract.
- [ ] Refactoring preserves behavior.
- [ ] A caller can use the service without reading its internals.

## Deliverables
- core.py with your implementation
- test_core.py with normal, empty, boundary, and invalid cases where applicable
- README.md with run commands, sample input/output, decisions, and limitations
- Evidence note: what you ran, what failed, what you changed, and help used

## References
- Python: classes: https://docs.python.org/3/tutorial/classes.html
- Python: modules: https://docs.python.org/3/tutorial/modules.html
- Python: typing: https://docs.python.org/3/library/typing.html
