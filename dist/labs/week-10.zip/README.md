# Week 10: Score service with a clear interface

## Start here

This ZIP is an unfinished checkpoint plus tests. The complete program in the build steps below is yours to create. Passing the supplied tests is only part of the lab.

1. Extract the ZIP into its own folder, for example Documents/Forge Work/week-10.
2. In VS Code, use File > Open Folder to open the folder containing core.py.
3. Choose Terminal > New Terminal. Type the commands below there, not in a .py file.
4. Need help installing Python or using the editor? Return to the Forge browser tab, open chapter 10 in the Quest book, open its independent lab brief, and select First lab? Start guided setup. This works in the local app and the public demo.

## Create the environment (once per lab folder)

Windows PowerShell:
```text
py -m venv .venv
.\.venv\Scripts\python.exe --version
```
macOS/Linux:
```text
python3 -m venv .venv
./.venv/bin/python --version
```
A Python 3 version number confirms the environment works. If Windows has python rather than py, use python -m venv .venv. Select this folder's .venv with VS Code's Python: Select Interpreter command. You do not need to activate it.

## Know the files

- core.py: implement the requested checkpoint function here.
- main.py: build the complete program here, calling functions from core.py as needed. The untouched file only prints a reminder.
- test_core.py: supplied checkpoint tests; add your own tests too.
- cases.json: inputs and expected results used by the supplied tests. Keep these intact.
- README.md: this brief; add your plan, run commands, and sample output here.

## Run tests after saving your files

Windows PowerShell:
```text
.\.venv\Scripts\python.exe -m unittest -v
```
macOS/Linux:
```text
./.venv/bin/python -m unittest -v
```
Expect assertion failures before you implement core.py. They compare the unfinished result with the expected result. An import ERROR or Ran 0 tests needs investigation: make sure the terminal is in the folder containing core.py, test_core.py, and cases.json. OK means the tests that ran passed; you must still check the full lab below. The kit uses built-in unittest, so no extra packages are needed for its tests.

## Run your program

Windows PowerShell:
```text
.\.venv\Scripts\python.exe main.py
```
macOS/Linux:
```text
./.venv/bin/python main.py
```
The untouched main.py is only a starting place. Replace its reminder with your own program. Install extra libraries in .venv only when a later lab needs them.

## Checkpoint contract

Write best_players(records). Each record has name and score. Keep each player’s highest score, then return names ordered by descending best score with alphabetical ties.

## Build the full lab

1. Model scores as data with a documented update policy.
2. Implement best-score updates and deterministic ranking.
3. Keep storage outside the scoring calculation.
4. Test two independent player instances if you use a class.
5. Document tie rules, invalid inputs, and whether updates mutate state.
6. Refactor one long function into small named steps while preserving tests.

## Acceptance criteria

- [ ] State is not unintentionally shared.
- [ ] Ranking ties match the contract.
- [ ] Refactoring preserves behavior.
- [ ] A caller can use the service without reading its internals.

## Deliverables

- core.py with your implementation
- main.py demonstrating the complete program
- test_core.py with normal, empty, boundary, and invalid cases where applicable
- README.md with run commands, sample input/output, decisions, and limitations
- Evidence note: what you ran, what failed, what you changed, and help used

## Evidence to record

Write your example input and expected output before coding. Then record the commands you ran, actual output, a bug you fixed, help used, and anything unfinished. Add at least one test of your own. Check the criteria in Forge after verifying them, and keep a backup of this folder separately from your Forge progress export.

## References

- Python: classes: https://docs.python.org/3/tutorial/classes.html
- Python: modules: https://docs.python.org/3/tutorial/modules.html
- Python: typing: https://docs.python.org/3/library/typing.html
