def best_players(records):
    # Write your solution here
    pass
