# Week 23: Ship two demonstrable workflows

This kit starts the checkpoint core. The complete local lab below goes beyond browser checks. Fill in core.py, add your own cases, then build the workflow.

## Setup

Windows PowerShell:
```text
py -m venv .venv
.venv\Scripts\python -m unittest -v
```
macOS/Linux:
```text
python3 -m venv .venv
.venv/bin/python -m unittest -v
```
The included tests start red because the implementation is yours to write. They use only the standard library. Install optional packages such as pytest, Requests, or FastAPI in this environment when the lab calls for them.

## Core challenge
Write release_ready(evidence). Return True only if the dictionary contains True (the actual bool) for each of tests, docs, clean_install, and demo. Missing, False, or truthy non-booleans fail. Ignore extra keys.

## Build the full lab
1. Finish the CLI import/search/report/export workflow.
2. Finish a small API or automation workflow using the same tested core.
3. Add real example input/output and a clear module map.
4. Create a fresh .venv and follow the README from scratch.
5. Run tests in a GitHub Actions workflow.
6. Introduce and repair a controlled failing test to verify CI.
7. Record a short demo and one design/bug-fix explanation.

## Acceptance criteria
- [ ] Clean installation is verified with commands.
- [ ] CLI and API/automation samples reproduce documented output.
- [ ] Tests run locally and in CI.
- [ ] Known limitations and help used are described honestly.

## Deliverables
- core.py with your implementation
- test_core.py with normal, empty, boundary, and invalid cases where applicable
- README.md with run commands, sample input/output, decisions, and limitations
- Evidence note: what you ran, what failed, what you changed, and help used

## References
- GitHub Actions: Python builds and tests: https://docs.github.com/en/actions/tutorials/build-and-test-code/python
- GitHub flow: https://docs.github.com/en/get-started/using-github/github-flow
- Python: virtual environments: https://docs.python.org/3/tutorial/venv.html
- FastAPI: first steps: https://fastapi.tiangolo.com/tutorial/first-steps/
- pytest: getting started: https://docs.pytest.org/en/stable/getting-started.html
