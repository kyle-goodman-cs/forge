def release_ready(evidence):
    # Plan, implement, then run the checks.
    pass
